package com.exxeta.hotelmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}

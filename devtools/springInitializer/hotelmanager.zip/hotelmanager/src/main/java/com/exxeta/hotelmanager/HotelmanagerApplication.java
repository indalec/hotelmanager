package com.exxeta.hotelmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelmanagerApplication.class, args);
	}

}
